"""
AIKLI Memory-Integrated Training

Memory must affect TRAINING, not just answers.
- Replay memory samples during training
- Increase loss weight on remembered failures
- Periodically fine-tune on long-term memory

That's how memory becomes learning, not just recall.
"""

import torch
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
from collections import deque
import numpy as np
import time


# ============================================================================
# TRAINING-INTEGRATED MEMORY
# ============================================================================

class TrainingMemory:
    """
    Memory system that directly affects training.
    
    Unlike passive memory (just for answers), this:
    - Replays samples during training
    - Weights losses based on failure history
    - Enables periodic fine-tuning on important memories
    """
    
    def __init__(
        self,
        capacity: int = 10000,
        failure_weight_multiplier: float = 2.0,
        replay_probability: float = 0.2
    ):
        # Success/failure tracking
        self.failures = deque(maxlen=capacity)  # Samples model got wrong
        self.hard_examples = deque(maxlen=capacity)  # High-loss samples
        self.important_samples = deque(maxlen=capacity)  # Manually marked important
        
        # Configuration
        self.failure_weight_multiplier = failure_weight_multiplier
        self.replay_probability = replay_probability
        
        # Statistics
        self.stats = {
            'total_failures': 0,
            'total_replays': 0,
            'weighted_batches': 0
        }
        
        print("✓ Training Memory initialized")
        print(f"  Capacity: {capacity}")
        print(f"  Failure weight multiplier: {failure_weight_multiplier}x")
        print(f"  Replay probability: {replay_probability:.1%}")
    
    def record_failure(self, sample: Dict, loss: float):
        """
        Record a sample the model failed on.
        
        Args:
            sample: {'input_ids': tensor, 'attention_mask': tensor}
            loss: loss value for this sample
        """
        self.failures.append({
            'sample': sample,
            'loss': loss,
            'timestamp': time.time(),
            'failure_count': 1
        })
        
        self.stats['total_failures'] += 1
    
    def record_hard_example(self, sample: Dict, loss: float, threshold: float = 3.0):
        """
        Record high-loss samples for focused training.
        
        Args:
            sample: training sample
            loss: loss value
            threshold: loss threshold to consider "hard"
        """
        if loss > threshold:
            self.hard_examples.append({
                'sample': sample,
                'loss': loss,
                'timestamp': time.time()
            })
    
    def mark_important(self, sample: Dict, reason: str = ""):
        """
        Manually mark sample as important.
        
        Args:
            sample: training sample
            reason: why it's important
        """
        self.important_samples.append({
            'sample': sample,
            'reason': reason,
            'timestamp': time.time()
        })
    
    def get_replay_batch(self, batch_size: int) -> Optional[Dict]:
        """
        Sample batch from memory for replay.
        
        Prioritizes:
        1. Recent failures (50%)
        2. Hard examples (30%)
        3. Important samples (20%)
        
        Returns:
            batch: {'input_ids': tensor, 'attention_mask': tensor} or None
        """
        if len(self.failures) == 0 and len(self.hard_examples) == 0:
            return None
        
        samples = []
        
        # Sample from failures (50% of batch)
        n_failures = min(batch_size // 2, len(self.failures))
        if n_failures > 0:
            failure_indices = np.random.choice(len(self.failures), n_failures, replace=False)
            samples.extend([self.failures[i]['sample'] for i in failure_indices])
        
        # Sample from hard examples (30% of batch)
        n_hard = min(batch_size * 3 // 10, len(self.hard_examples))
        if n_hard > 0:
            hard_indices = np.random.choice(len(self.hard_examples), n_hard, replace=False)
            samples.extend([self.hard_examples[i]['sample'] for i in hard_indices])
        
        # Sample from important (20% of batch)
        n_important = min(batch_size // 5, len(self.important_samples))
        if n_important > 0:
            important_indices = np.random.choice(len(self.important_samples), n_important, replace=False)
            samples.extend([self.important_samples[i]['sample'] for i in important_indices])
        
        if len(samples) == 0:
            return None
        
        # Combine into batch
        input_ids = torch.cat([s['input_ids'].unsqueeze(0) for s in samples], dim=0)
        attention_mask = torch.cat([s['attention_mask'].unsqueeze(0) for s in samples], dim=0)
        
        self.stats['total_replays'] += 1
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask
        }
    
    def get_loss_weights(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Get loss weights for a batch based on failure history.
        
        Samples with more failures get higher weight.
        
        Args:
            input_ids: (batch, seq_len)
            
        Returns:
            weights: (batch,) tensor of loss weights
        """
        batch_size = input_ids.shape[0]
        weights = torch.ones(batch_size)
        
        # Check if any samples in batch are in failure memory
        for i in range(batch_size):
            sample_id = input_ids[i].cpu().numpy().tobytes()
            
            # Count failures for this sample
            failure_count = sum(
                1 for f in self.failures
                if f['sample']['input_ids'].cpu().numpy().tobytes() == sample_id
            )
            
            if failure_count > 0:
                weights[i] = self.failure_weight_multiplier ** failure_count
                self.stats['weighted_batches'] += 1
        
        return weights
    
    def should_replay(self) -> bool:
        """Decide whether to include replay samples in current batch."""
        return np.random.random() < self.replay_probability and len(self.failures) > 0
    
    def get_fine_tuning_data(self, max_samples: int = 1000) -> Optional[Dict]:
        """
        Get data for periodic fine-tuning on long-term memory.
        
        Returns most important samples:
        - All important samples
        - Recent failures
        - Hardest examples
        
        Args:
            max_samples: maximum number of samples to return
            
        Returns:
            batch: combined memory samples or None
        """
        all_samples = []
        
        # All important samples
        all_samples.extend([s['sample'] for s in self.important_samples])
        
        # Recent failures
        n_failures = min(max_samples // 2, len(self.failures))
        recent_failures = list(self.failures)[-n_failures:]
        all_samples.extend([f['sample'] for f in recent_failures])
        
        # Hardest examples
        if len(self.hard_examples) > 0:
            sorted_hard = sorted(self.hard_examples, key=lambda x: x['loss'], reverse=True)
            n_hard = min(max_samples // 4, len(sorted_hard))
            all_samples.extend([h['sample'] for h in sorted_hard[:n_hard]])
        
        if len(all_samples) == 0:
            return None
        
        # Deduplicate and limit
        all_samples = all_samples[:max_samples]
        
        # Combine
        input_ids = torch.cat([s['input_ids'].unsqueeze(0) for s in all_samples], dim=0)
        attention_mask = torch.cat([s['attention_mask'].unsqueeze(0) for s in all_samples], dim=0)
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask
        }
    
    def clear_old_memories(self, max_age_seconds: float = 86400):
        """
        Clear memories older than max_age.
        
        Args:
            max_age_seconds: memories older than this are removed (default: 24 hours)
        """
        current_time = time.time()
        
        # Clear old failures
        self.failures = deque([
            f for f in self.failures
            if current_time - f['timestamp'] < max_age_seconds
        ], maxlen=self.failures.maxlen)
        
        # Clear old hard examples
        self.hard_examples = deque([
            h for h in self.hard_examples
            if current_time - h['timestamp'] < max_age_seconds
        ], maxlen=self.hard_examples.maxlen)
        
        print(f"✓ Cleared memories older than {max_age_seconds/3600:.1f} hours")
    
    def get_stats(self) -> Dict:
        """Get memory statistics."""
        return {
            'num_failures': len(self.failures),
            'num_hard_examples': len(self.hard_examples),
            'num_important': len(self.important_samples),
            'total_failures_recorded': self.stats['total_failures'],
            'total_replays': self.stats['total_replays'],
            'weighted_batches': self.stats['weighted_batches']
        }


# ============================================================================
# MEMORY-INTEGRATED TRAINER
# ============================================================================

class MemoryIntegratedTrainer:
    """
    Training engine with integrated memory.
    
    Memory actively affects training:
    - Replays failures during training
    - Weights losses based on failure history
    - Enables periodic fine-tuning
    """
    
    def __init__(
        self,
        model,
        optimizer,
        memory: TrainingMemory,
        device: str = 'cuda'
    ):
        self.model = model
        self.optimizer = optimizer
        self.memory = memory
        self.device = device
        
        print("✓ Memory-Integrated Trainer initialized")
    
    def train_step_with_memory(
        self,
        batch: Dict,
        record_failures: bool = True
    ) -> Dict:
        """
        Training step with memory integration.
        
        1. Process current batch
        2. Optionally add replay samples
        3. Weight losses based on failure history
        4. Record new failures
        
        Args:
            batch: current training batch
            record_failures: whether to record failures this step
            
        Returns:
            metrics: training metrics
        """
        self.model.train()
        
        input_ids = batch['input_ids'].to(self.device)
        attention_mask = batch['attention_mask'].to(self.device)
        
        # Decide if we should add replay samples
        if self.memory.should_replay():
            replay_batch = self.memory.get_replay_batch(batch_size=input_ids.shape[0] // 4)
            
            if replay_batch is not None:
                # Combine current batch with replay
                input_ids = torch.cat([
                    input_ids,
                    replay_batch['input_ids'].to(self.device)
                ], dim=0)
                
                attention_mask = torch.cat([
                    attention_mask,
                    replay_batch['attention_mask'].to(self.device)
                ], dim=0)
        
        # Zero gradients
        self.optimizer.zero_grad()
        
        # Forward pass
        logits = self.model(input_ids, attention_mask)
        
        # Compute per-sample losses
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = input_ids[:, 1:].contiguous()
        shift_mask = attention_mask[:, 1:].contiguous()
        
        # Compute loss per sample (no reduction yet)
        losses = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            reduction='none'
        )
        
        # Reshape to (batch, seq_len-1)
        losses = losses.view(input_ids.shape[0], -1)
        
        # Apply attention mask
        masked_losses = losses * shift_mask
        
        # Compute per-sample average loss
        sample_losses = masked_losses.sum(dim=1) / shift_mask.sum(dim=1)
        
        # Get loss weights from memory
        loss_weights = self.memory.get_loss_weights(input_ids).to(self.device)
        
        # Apply weights and compute final loss
        weighted_losses = sample_losses * loss_weights
        final_loss = weighted_losses.mean()
        
        # Backward pass
        final_loss.backward()
        
        # Gradient clipping
        grad_norm = torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        
        # Optimizer step
        self.optimizer.step()
        
        # Record failures (samples with high loss)
        if record_failures:
            for i in range(input_ids.shape[0]):
                loss_val = sample_losses[i].item()
                
                # Record as failure if loss is high
                if loss_val > 3.0:
                    self.memory.record_failure(
                        sample={
                            'input_ids': input_ids[i].cpu(),
                            'attention_mask': attention_mask[i].cpu()
                        },
                        loss=loss_val
                    )
                
                # Record as hard example
                self.memory.record_hard_example(
                    sample={
                        'input_ids': input_ids[i].cpu(),
                        'attention_mask': attention_mask[i].cpu()
                    },
                    loss=loss_val,
                    threshold=3.0
                )
        
        return {
            'loss': final_loss.item(),
            'avg_sample_loss': sample_losses.mean().item(),
            'max_sample_loss': sample_losses.max().item(),
            'grad_norm': grad_norm.item(),
            'memory_stats': self.memory.get_stats()
        }
    
    def fine_tune_on_memory(
        self,
        num_steps: int = 100,
        learning_rate: float = 1e-5
    ):
        """
        Periodic fine-tuning on long-term memory.
        
        This reinforces important patterns from memory.
        
        Args:
            num_steps: number of fine-tuning steps
            learning_rate: learning rate for fine-tuning
        """
        print(f"\n{'='*70}")
        print("FINE-TUNING ON LONG-TERM MEMORY")
        print(f"{'='*70}")
        
        # Get memory data
        memory_data = self.memory.get_fine_tuning_data(max_samples=1000)
        
        if memory_data is None:
            print("No memory data available for fine-tuning")
            return
        
        print(f"Fine-tuning on {memory_data['input_ids'].shape[0]} memory samples")
        
        # Create temporary optimizer with lower learning rate
        temp_optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=learning_rate,
            weight_decay=0.01
        )
        
        # Fine-tune
        self.model.train()
        
        for step in range(num_steps):
            # Random subset of memory
            batch_size = 8
            indices = np.random.choice(
                memory_data['input_ids'].shape[0],
                min(batch_size, memory_data['input_ids'].shape[0]),
                replace=False
            )
            
            input_ids = memory_data['input_ids'][indices].to(self.device)
            attention_mask = memory_data['attention_mask'][indices].to(self.device)
            
            # Forward
            temp_optimizer.zero_grad()
            logits = self.model(input_ids, attention_mask)
            
            # Loss
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = input_ids[:, 1:].contiguous()
            shift_mask = attention_mask[:, 1:].contiguous()
            
            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                reduction='none'
            )
            
            loss = (loss * shift_mask.view(-1)).sum() / shift_mask.sum()
            
            # Backward
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            temp_optimizer.step()
            
            if step % 20 == 0:
                print(f"  Step {step}/{num_steps}: Loss={loss.item():.4f}")
        
        print(f"✓ Fine-tuning complete")
        print(f"{'='*70}")


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("Testing Memory-Integrated Training...")
    print("="*70)
    
    # Create memory
    memory = TrainingMemory(capacity=1000)
    
    # Test recording failures
    dummy_sample = {
        'input_ids': torch.randint(0, 100, (64,)),
        'attention_mask': torch.ones(64)
    }
    
    memory.record_failure(dummy_sample, loss=5.2)
    memory.record_hard_example(dummy_sample, loss=4.1)
    
    assert len(memory.failures) == 1, "Should record failure"
    assert len(memory.hard_examples) == 1, "Should record hard example"
    
    print("✓ Failure recording works")
    
    # Test replay batch
    for _ in range(10):
        memory.record_failure(dummy_sample, loss=3.5)
    
    replay_batch = memory.get_replay_batch(batch_size=4)
    assert replay_batch is not None, "Should generate replay batch"
    assert replay_batch['input_ids'].shape[0] <= 4, "Batch size should be correct"
    
    print("✓ Replay batch generation works")
    
    # Test loss weighting
    input_ids_batch = torch.randint(0, 100, (4, 64))
    weights = memory.get_loss_weights(input_ids_batch)
    assert weights.shape[0] == 4, "Should return weights for all samples"
    
    print("✓ Loss weighting works")
    
    # Test fine-tuning data
    memory.mark_important(dummy_sample, reason="Test sample")
    ft_data = memory.get_fine_tuning_data(max_samples=100)
    assert ft_data is not None, "Should generate fine-tuning data"
    
    print("✓ Fine-tuning data generation works")
    
    # Test stats
    stats = memory.get_stats()
    assert stats['num_failures'] > 0, "Should track failures"
    print(f"✓ Memory stats: {stats}")
    
    print("\n" + "="*70)
    print("✓ ALL TESTS PASSED - MEMORY-INTEGRATED TRAINING READY")
    print("="*70)
