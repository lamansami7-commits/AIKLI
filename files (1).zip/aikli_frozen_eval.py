"""
AIKLI Frozen Evaluation System

Evaluation must be:
- Numerical and exact (not heuristic)
- Deterministic (temperature=0, fixed seeds)
- Reproducible (same prompts every time)
- Graphable (save results to disk per epoch)

If you can't graph improvement, you can't claim it.
"""

import torch
import numpy as np
from typing import Dict, List, Tuple
import json
from dataclasses import dataclass, asdict
from datetime import datetime


# ============================================================================
# FROZEN EVALUATION PROMPTS
# ============================================================================

@dataclass
class EvalPrompt:
    """Single evaluation prompt with expected answer."""
    id: str
    prompt: str
    expected_answer: str
    category: str
    metric_type: str  # 'exact_match', 'contains', 'numerical'


class FrozenEvaluationSet:
    """
    Fixed evaluation prompts that never change.
    Same prompts, same order, every time.
    """
    
    def __init__(self):
        # These prompts are FROZEN - never change them
        self.prompts = [
            # Factual knowledge
            EvalPrompt(
                id="fact_001",
                prompt="Q: How many continents are there? A:",
                expected_answer="7",
                category="factual",
                metric_type="contains"
            ),
            EvalPrompt(
                id="fact_002",
                prompt="Q: What is the capital of France? A:",
                expected_answer="Paris",
                category="factual",
                metric_type="contains"
            ),
            EvalPrompt(
                id="fact_003",
                prompt="Q: How many sides does a triangle have? A:",
                expected_answer="3",
                category="factual",
                metric_type="contains"
            ),
            EvalPrompt(
                id="fact_004",
                prompt="Q: What is the chemical symbol for water? A:",
                expected_answer="H2O",
                category="factual",
                metric_type="contains"
            ),
            EvalPrompt(
                id="fact_005",
                prompt="Q: What planet do we live on? A:",
                expected_answer="Earth",
                category="factual",
                metric_type="contains"
            ),
            
            # Simple math
            EvalPrompt(
                id="math_001",
                prompt="Q: What is 2 + 2? A:",
                expected_answer="4",
                category="math",
                metric_type="exact_match"
            ),
            EvalPrompt(
                id="math_002",
                prompt="Q: What is 5 * 3? A:",
                expected_answer="15",
                category="math",
                metric_type="exact_match"
            ),
            EvalPrompt(
                id="math_003",
                prompt="Q: What is 10 - 7? A:",
                expected_answer="3",
                category="math",
                metric_type="exact_match"
            ),
            
            # Instruction following
            EvalPrompt(
                id="inst_001",
                prompt="List three colors:",
                expected_answer="red blue green",  # Any three colors counts
                category="instruction",
                metric_type="contains"
            ),
            EvalPrompt(
                id="inst_002",
                prompt="Count from 1 to 3:",
                expected_answer="1 2 3",
                category="instruction",
                metric_type="contains"
            ),
            
            # Completion
            EvalPrompt(
                id="comp_001",
                prompt="The quick brown fox",
                expected_answer="jumps",
                category="completion",
                metric_type="contains"
            ),
            EvalPrompt(
                id="comp_002",
                prompt="Once upon a",
                expected_answer="time",
                category="completion",
                metric_type="contains"
            ),
            
            # Reasoning
            EvalPrompt(
                id="reason_001",
                prompt="Q: If all birds can fly, and a penguin is a bird, can a penguin fly? A:",
                expected_answer="yes",  # Tests logical reasoning (even if factually wrong)
                category="reasoning",
                metric_type="contains"
            ),
            EvalPrompt(
                id="reason_002",
                prompt="Q: John is taller than Mary. Mary is taller than Sue. Who is tallest? A:",
                expected_answer="John",
                category="reasoning",
                metric_type="contains"
            ),
            
            # Long context (tests if model can maintain coherence)
            EvalPrompt(
                id="long_001",
                prompt="The secret code is 7294. Additional context here. More text. What was the code? A:",
                expected_answer="7294",
                category="long_context",
                metric_type="exact_match"
            ),
        ]
        
        self.categories = list(set(p.category for p in self.prompts))
        
        print(f"✓ Frozen evaluation set loaded: {len(self.prompts)} prompts")
        print(f"  Categories: {', '.join(self.categories)}")
    
    def get_prompts(self, category: str = None) -> List[EvalPrompt]:
        """Get prompts, optionally filtered by category."""
        if category is None:
            return self.prompts
        return [p for p in self.prompts if p.category == category]
    
    def save(self, path: str):
        """Save evaluation set to disk."""
        data = [asdict(p) for p in self.prompts]
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"✓ Evaluation set saved: {path}")


# ============================================================================
# DETERMINISTIC EVALUATOR
# ============================================================================

class DeterministicEvaluator:
    """
    Evaluator with deterministic generation.
    - Temperature = 0 (greedy decoding)
    - Fixed random seed
    - Same prompts every time
    - Numerical metrics (exact match, contains, etc.)
    """
    
    def __init__(
        self,
        model,
        tokenizer,
        eval_set: FrozenEvaluationSet,
        device: str = 'cuda',
        max_new_tokens: int = 50
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.eval_set = eval_set
        self.device = device
        self.max_new_tokens = max_new_tokens
        
        # Evaluation history (saved to disk)
        self.history = []
        
        print("✓ Deterministic Evaluator initialized")
        print(f"  Evaluation prompts: {len(eval_set.prompts)}")
        print(f"  Max new tokens: {max_new_tokens}")
        print(f"  Decoding: Greedy (temperature=0)")
    
    def _compute_metric(self, generated: str, expected: str, metric_type: str) -> float:
        """
        Compute numerical metric.
        
        Returns:
            score: 0.0 or 1.0 (binary correct/incorrect)
        """
        generated_clean = generated.strip().lower()
        expected_clean = expected.strip().lower()
        
        if metric_type == 'exact_match':
            # Extract first number or word
            gen_parts = generated_clean.split()
            exp_parts = expected_clean.split()
            
            if len(gen_parts) > 0 and len(exp_parts) > 0:
                return 1.0 if gen_parts[0] == exp_parts[0] else 0.0
            return 0.0
        
        elif metric_type == 'contains':
            # Check if expected is in generated
            return 1.0 if expected_clean in generated_clean else 0.0
        
        elif metric_type == 'numerical':
            # Extract numbers and compare
            try:
                gen_num = float(''.join(c for c in generated_clean if c.isdigit() or c == '.'))
                exp_num = float(expected_clean)
                return 1.0 if abs(gen_num - exp_num) < 0.01 else 0.0
            except:
                return 0.0
        
        return 0.0
    
    @torch.no_grad()
    def evaluate_single(self, prompt: EvalPrompt) -> Dict:
        """
        Evaluate single prompt deterministically.
        
        Returns:
            result: {
                'prompt_id': str,
                'generated': str,
                'expected': str,
                'score': float (0.0 or 1.0),
                'correct': bool
            }
        """
        self.model.eval()
        
        # Set seed for reproducibility
        torch.manual_seed(42)
        np.random.seed(42)
        
        # Encode prompt
        input_ids = self.tokenizer.encode(
            prompt.prompt,
            return_tensors='pt',
            max_length=512,
            truncation=True
        ).to(self.device)
        
        # Generate with temperature=0 (deterministic)
        output_ids = self.model.generate(
            input_ids,
            max_new_tokens=self.max_new_tokens,
            temperature=0.0,  # DETERMINISTIC
            do_sample=False,  # GREEDY
            pad_token_id=self.tokenizer.base.pad_token_id
        )
        
        # Decode
        generated_full = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        
        # Extract only the generated part (after prompt)
        generated = generated_full[len(prompt.prompt):].strip()
        
        # Compute metric
        score = self._compute_metric(generated, prompt.expected_answer, prompt.metric_type)
        
        return {
            'prompt_id': prompt.id,
            'category': prompt.category,
            'generated': generated[:100],  # Truncate for logging
            'expected': prompt.expected_answer,
            'score': score,
            'correct': score > 0.5
        }
    
    def evaluate_all(self, epoch: int = None) -> Dict:
        """
        Evaluate on all prompts.
        
        Returns:
            results: {
                'timestamp': str,
                'epoch': int,
                'overall_accuracy': float,
                'category_accuracies': Dict[str, float],
                'individual_results': List[Dict],
                'total_prompts': int,
                'correct_prompts': int
            }
        """
        print("\n" + "="*70)
        print("DETERMINISTIC EVALUATION")
        print("="*70)
        
        all_results = []
        category_results = {cat: [] for cat in self.eval_set.categories}
        
        # Evaluate each prompt
        for i, prompt in enumerate(self.eval_set.prompts):
            result = self.evaluate_single(prompt)
            all_results.append(result)
            category_results[prompt.category].append(result['score'])
            
            # Print progress
            if (i + 1) % 5 == 0:
                print(f"  Evaluated {i+1}/{len(self.eval_set.prompts)} prompts")
        
        # Compute overall accuracy
        total_correct = sum(r['score'] for r in all_results)
        overall_accuracy = total_correct / len(all_results)
        
        # Compute category accuracies
        category_accuracies = {}
        for cat, scores in category_results.items():
            if len(scores) > 0:
                category_accuracies[cat] = sum(scores) / len(scores)
        
        # Create results
        eval_results = {
            'timestamp': datetime.now().isoformat(),
            'epoch': epoch,
            'overall_accuracy': overall_accuracy,
            'category_accuracies': category_accuracies,
            'individual_results': all_results,
            'total_prompts': len(all_results),
            'correct_prompts': int(total_correct)
        }
        
        # Print summary
        print("\n" + "="*70)
        print("EVALUATION RESULTS")
        print("="*70)
        print(f"Overall Accuracy: {overall_accuracy:.1%} ({int(total_correct)}/{len(all_results)})")
        print("\nBy Category:")
        for cat, acc in category_accuracies.items():
            num_prompts = len(category_results[cat])
            print(f"  {cat:15s}: {acc:.1%} ({int(acc * num_prompts)}/{num_prompts})")
        print("="*70)
        
        # Store in history
        self.history.append(eval_results)
        
        return eval_results
    
    def save_results(self, path: str):
        """Save evaluation history to disk."""
        with open(path, 'w') as f:
            json.dump(self.history, f, indent=2, default=str)
        print(f"✓ Evaluation results saved: {path}")
    
    def load_results(self, path: str):
        """Load evaluation history from disk."""
        with open(path, 'r') as f:
            self.history = json.load(f)
        print(f"✓ Evaluation results loaded: {path}")
        print(f"  History length: {len(self.history)} evaluations")
    
    def plot_progress(self) -> str:
        """
        Generate ASCII plot of evaluation progress.
        
        Returns:
            plot: string representation of progress
        """
        if len(self.history) == 0:
            return "No evaluation history to plot"
        
        epochs = [h.get('epoch', i) for i, h in enumerate(self.history)]
        accuracies = [h['overall_accuracy'] * 100 for h in self.history]
        
        # Create ASCII plot
        plot_lines = []
        plot_lines.append("\n" + "="*70)
        plot_lines.append("EVALUATION PROGRESS")
        plot_lines.append("="*70)
        
        max_acc = max(accuracies)
        min_acc = min(accuracies)
        
        plot_lines.append(f"\nEpochs: {epochs[0]} → {epochs[-1]}")
        plot_lines.append(f"Accuracy: {min_acc:.1f}% → {max_acc:.1f}%")
        plot_lines.append(f"Improvement: {max_acc - min_acc:.1f} percentage points")
        plot_lines.append("\nProgress:")
        
        # Simple bar chart
        for epoch, acc in zip(epochs, accuracies):
            bar_length = int(acc / 2)  # Scale to 50 chars max
            bar = '█' * bar_length
            plot_lines.append(f"  Epoch {epoch:3d}: {bar} {acc:.1f}%")
        
        plot_lines.append("="*70)
        
        return "\n".join(plot_lines)
    
    def check_regression(self, threshold: float = 0.05) -> Dict:
        """
        Check for regression in performance.
        
        Args:
            threshold: accuracy drop (in percentage points) to flag as regression
            
        Returns:
            regression_info: {
                'has_regression': bool,
                'max_accuracy': float,
                'current_accuracy': float,
                'drop': float
            }
        """
        if len(self.history) < 2:
            return {'has_regression': False}
        
        accuracies = [h['overall_accuracy'] for h in self.history]
        max_accuracy = max(accuracies)
        current_accuracy = accuracies[-1]
        
        drop = (max_accuracy - current_accuracy) * 100  # Convert to percentage points
        
        has_regression = drop > threshold
        
        if has_regression:
            print(f"\n⚠ REGRESSION DETECTED")
            print(f"  Max accuracy: {max_accuracy:.1%}")
            print(f"  Current accuracy: {current_accuracy:.1%}")
            print(f"  Drop: {drop:.1f} percentage points")
        
        return {
            'has_regression': has_regression,
            'max_accuracy': max_accuracy,
            'current_accuracy': current_accuracy,
            'drop': drop
        }


# ============================================================================
# BENCHMARK GATES (Curriculum Advancement Criteria)
# ============================================================================

class BenchmarkGate:
    """
    Gate that prevents curriculum advancement unless benchmark passed.
    
    This is governance, not suggestion.
    """
    
    def __init__(
        self,
        name: str,
        min_overall_accuracy: float = 0.6,
        min_category_accuracies: Dict[str, float] = None,
        regression_tolerance: float = 0.05
    ):
        self.name = name
        self.min_overall_accuracy = min_overall_accuracy
        self.min_category_accuracies = min_category_accuracies or {}
        self.regression_tolerance = regression_tolerance
        
        print(f"✓ Benchmark gate '{name}' created")
        print(f"  Min overall accuracy: {min_overall_accuracy:.1%}")
        if min_category_accuracies:
            print(f"  Category requirements:")
            for cat, min_acc in min_category_accuracies.items():
                print(f"    {cat}: {min_acc:.1%}")
    
    def check(self, eval_results: Dict, baseline_results: Dict = None) -> Tuple[bool, str]:
        """
        Check if benchmark gate is passed.
        
        Returns:
            (passed, reason)
        """
        # Check overall accuracy
        if eval_results['overall_accuracy'] < self.min_overall_accuracy:
            return False, f"Overall accuracy {eval_results['overall_accuracy']:.1%} < {self.min_overall_accuracy:.1%}"
        
        # Check category accuracies
        for cat, min_acc in self.min_category_accuracies.items():
            actual_acc = eval_results['category_accuracies'].get(cat, 0.0)
            if actual_acc < min_acc:
                return False, f"Category '{cat}' accuracy {actual_acc:.1%} < {min_acc:.1%}"
        
        # Check regression
        if baseline_results is not None:
            baseline_acc = baseline_results['overall_accuracy']
            current_acc = eval_results['overall_accuracy']
            drop = (baseline_acc - current_acc) * 100
            
            if drop > self.regression_tolerance * 100:
                return False, f"Regression detected: {drop:.1f}pp drop from baseline"
        
        return True, "All benchmarks passed"


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("Testing Frozen Evaluation System...")
    print("="*70)
    
    # Create evaluation set
    eval_set = FrozenEvaluationSet()
    
    # Save/load test
    eval_set.save('./test_eval_set.json')
    print("✓ Evaluation set saved")
    
    # Test metric computation
    evaluator = DeterministicEvaluator(
        model=None,  # Mock
        tokenizer=None,  # Mock
        eval_set=eval_set,
        device='cpu'
    )
    
    # Test exact match
    score = evaluator._compute_metric("4", "4", "exact_match")
    assert score == 1.0, "Exact match should work"
    
    score = evaluator._compute_metric("5", "4", "exact_match")
    assert score == 0.0, "Exact match should fail on mismatch"
    
    # Test contains
    score = evaluator._compute_metric("The answer is Paris", "Paris", "contains")
    assert score == 1.0, "Contains should work"
    
    print("✓ Metric computation works")
    
    # Test benchmark gate
    gate = BenchmarkGate(
        name="Stage 1 Gate",
        min_overall_accuracy=0.6,
        min_category_accuracies={'factual': 0.7, 'math': 0.8}
    )
    
    # Mock results
    mock_results = {
        'overall_accuracy': 0.65,
        'category_accuracies': {'factual': 0.75, 'math': 0.85}
    }
    
    passed, reason = gate.check(mock_results)
    assert passed, "Should pass benchmark gate"
    print(f"✓ Benchmark gate: {reason}")
    
    # Test failure
    mock_results['category_accuracies']['math'] = 0.5
    passed, reason = gate.check(mock_results)
    assert not passed, "Should fail benchmark gate"
    print(f"✓ Benchmark gate correctly fails: {reason}")
    
    print("\n" + "="*70)
    print("✓ ALL TESTS PASSED - FROZEN EVALUATION READY")
    print("="*70)
