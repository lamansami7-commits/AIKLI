"""
AIKLI Training Engine - THE ACTUAL BRAIN

This is what was missing: the real training loop that makes learning happen.
- Forward pass
- Loss calculation
- Backward pass
- Optimizer stepping
- Gradient logging

Without this, nothing learns. This is the engine.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Optional, Tuple
import math
import time
from dataclasses import dataclass
import json


# ============================================================================
# REAL MODEL ARCHITECTURE (NOT ASSUMED)
# ============================================================================

@dataclass
class ModelConfig:
    """Explicit model configuration - nothing assumed."""
    vocab_size: int = 50257
    max_seq_len: int = 1024
    d_model: int = 512
    num_layers: int = 6
    num_heads: int = 8
    d_ff: int = 2048
    dropout: float = 0.1
    
    def __post_init__(self):
        assert self.d_model % self.num_heads == 0, "d_model must be divisible by num_heads"
        assert self.d_ff >= self.d_model, "d_ff should be >= d_model"


class TransformerBlock(nn.Module):
    """Single transformer block with multi-head attention."""
    
    def __init__(self, config: ModelConfig):
        super().__init__()
        
        # Multi-head attention
        self.attention = nn.MultiheadAttention(
            embed_dim=config.d_model,
            num_heads=config.num_heads,
            dropout=config.dropout,
            batch_first=True
        )
        
        # Feed-forward network
        self.ff = nn.Sequential(
            nn.Linear(config.d_model, config.d_ff),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.d_ff, config.d_model),
            nn.Dropout(config.dropout)
        )
        
        # Layer norms
        self.ln1 = nn.LayerNorm(config.d_model)
        self.ln2 = nn.LayerNorm(config.d_model)
        
        self.dropout = nn.Dropout(config.dropout)
    
    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None):
        """
        Args:
            x: (batch, seq_len, d_model)
            mask: (seq_len, seq_len) causal mask
        """
        # Multi-head attention with residual
        attn_out, _ = self.attention(x, x, x, attn_mask=mask, need_weights=False)
        x = self.ln1(x + self.dropout(attn_out))
        
        # Feed-forward with residual
        ff_out = self.ff(x)
        x = self.ln2(x + ff_out)
        
        return x


class AIKLILanguageModel(nn.Module):
    """
    Actual transformer language model.
    Explicit architecture - nothing assumed.
    """
    
    def __init__(self, config: ModelConfig):
        super().__init__()
        
        self.config = config
        
        # Token embeddings
        self.token_embedding = nn.Embedding(config.vocab_size, config.d_model)
        
        # Positional embeddings
        self.pos_embedding = nn.Embedding(config.max_seq_len, config.d_model)
        
        # Transformer blocks
        self.blocks = nn.ModuleList([
            TransformerBlock(config) for _ in range(config.num_layers)
        ])
        
        # Output projection
        self.ln_final = nn.LayerNorm(config.d_model)
        self.output = nn.Linear(config.d_model, config.vocab_size, bias=False)
        
        # Tie weights (embeddings and output projection share weights)
        self.output.weight = self.token_embedding.weight
        
        # Initialize weights
        self.apply(self._init_weights)
        
        print(f"✓ Model initialized: {self.count_parameters()/1e6:.1f}M parameters")
    
    def _init_weights(self, module):
        """Initialize weights properly."""
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
        elif isinstance(module, nn.LayerNorm):
            torch.nn.init.ones_(module.weight)
            torch.nn.init.zeros_(module.bias)
    
    def forward(self, input_ids: torch.Tensor, attention_mask: Optional[torch.Tensor] = None):
        """
        Forward pass - THE ACTUAL COMPUTATION.
        
        Args:
            input_ids: (batch, seq_len) token IDs
            attention_mask: (batch, seq_len) 1 for real tokens, 0 for padding
            
        Returns:
            logits: (batch, seq_len, vocab_size)
        """
        batch_size, seq_len = input_ids.shape
        
        # Create position IDs
        position_ids = torch.arange(seq_len, device=input_ids.device).unsqueeze(0).expand(batch_size, -1)
        
        # Embeddings
        token_emb = self.token_embedding(input_ids)  # (batch, seq_len, d_model)
        pos_emb = self.pos_embedding(position_ids)   # (batch, seq_len, d_model)
        
        x = token_emb + pos_emb
        
        # Create causal mask (prevent attending to future tokens)
        causal_mask = self._create_causal_mask(seq_len, device=input_ids.device)
        
        # Pass through transformer blocks
        for block in self.blocks:
            x = block(x, mask=causal_mask)
        
        # Final layer norm
        x = self.ln_final(x)
        
        # Project to vocabulary
        logits = self.output(x)  # (batch, seq_len, vocab_size)
        
        return logits
    
    def _create_causal_mask(self, seq_len: int, device: torch.device) -> torch.Tensor:
        """Create causal attention mask."""
        mask = torch.triu(torch.ones(seq_len, seq_len, device=device), diagonal=1)
        mask = mask.masked_fill(mask == 1, float('-inf'))
        return mask
    
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 50,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        do_sample: bool = True,
        pad_token_id: int = 0
    ) -> torch.Tensor:
        """
        Generate new tokens autoregressively.
        
        Args:
            input_ids: (batch, seq_len) starting tokens
            max_new_tokens: how many tokens to generate
            temperature: sampling temperature (0 = greedy)
            top_k: if set, only sample from top k tokens
            top_p: if set, nucleus sampling
            do_sample: whether to sample or take argmax
        """
        self.eval()
        
        generated = input_ids.clone()
        
        with torch.no_grad():
            for _ in range(max_new_tokens):
                # Truncate if exceeds max length
                if generated.shape[1] > self.config.max_seq_len:
                    generated = generated[:, -self.config.max_seq_len:]
                
                # Forward pass
                logits = self.forward(generated)  # (batch, seq_len, vocab_size)
                
                # Get logits for next token
                next_token_logits = logits[:, -1, :]  # (batch, vocab_size)
                
                # Apply temperature
                if temperature > 0:
                    next_token_logits = next_token_logits / temperature
                
                # Top-k sampling
                if top_k is not None:
                    indices_to_remove = next_token_logits < torch.topk(next_token_logits, top_k)[0][..., -1, None]
                    next_token_logits[indices_to_remove] = float('-inf')
                
                # Top-p (nucleus) sampling
                if top_p is not None:
                    sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True)
                    cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                    
                    # Remove tokens with cumulative probability above threshold
                    sorted_indices_to_remove = cumulative_probs > top_p
                    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                    sorted_indices_to_remove[..., 0] = 0
                    
                    indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
                    next_token_logits[indices_to_remove] = float('-inf')
                
                # Sample or take argmax
                if do_sample and temperature > 0:
                    probs = F.softmax(next_token_logits, dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1)
                else:
                    next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)
                
                # Append to sequence
                generated = torch.cat([generated, next_token], dim=1)
        
        return generated
    
    def count_parameters(self) -> int:
        """Count total parameters."""
        return sum(p.numel() for p in self.parameters())


# ============================================================================
# REAL TRAINING LOOP (THE ENGINE)
# ============================================================================

class TrainingEngine:
    """
    The actual training loop that makes learning happen.
    
    This is what was missing:
    - Forward pass
    - Loss calculation
    - Backward pass
    - Optimizer step
    - Logging
    """
    
    def __init__(
        self,
        model: AIKLILanguageModel,
        train_loader: DataLoader,
        val_loader: DataLoader,
        learning_rate: float = 3e-4,
        weight_decay: float = 0.01,
        max_grad_norm: float = 1.0,
        warmup_steps: int = 100,
        device: str = 'cuda'
    ):
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.max_grad_norm = max_grad_norm
        
        # Optimizer
        self.optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay,
            betas=(0.9, 0.95)
        )
        
        # Learning rate scheduler with warmup
        self.warmup_steps = warmup_steps
        self.base_lr = learning_rate
        self.global_step = 0
        
        # Metrics tracking
        self.metrics = {
            'train_losses': [],
            'train_ppls': [],
            'val_losses': [],
            'val_ppls': [],
            'learning_rates': [],
            'grad_norms': [],
            'step_times': []
        }
        
        print("✓ Training Engine initialized")
        print(f"  Optimizer: AdamW (lr={learning_rate:.2e}, wd={weight_decay})")
        print(f"  Warmup steps: {warmup_steps}")
        print(f"  Max grad norm: {max_grad_norm}")
    
    def _get_lr(self) -> float:
        """Get learning rate with warmup."""
        if self.global_step < self.warmup_steps:
            # Linear warmup
            return self.base_lr * (self.global_step / self.warmup_steps)
        else:
            # Cosine decay after warmup
            progress = (self.global_step - self.warmup_steps) / max(1, 10000 - self.warmup_steps)
            return self.base_lr * 0.5 * (1 + math.cos(math.pi * progress))
    
    def _update_lr(self):
        """Update learning rate."""
        lr = self._get_lr()
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr
        return lr
    
    def train_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """
        Single training step - THE CORE LEARNING LOOP.
        
        This is where learning actually happens:
        1. Forward pass
        2. Compute loss
        3. Backward pass
        4. Optimizer step
        
        Args:
            batch: {'input_ids': (batch, seq_len), 'attention_mask': (batch, seq_len)}
            
        Returns:
            metrics: {'loss': float, 'ppl': float, 'grad_norm': float}
        """
        self.model.train()
        
        # Move to device
        input_ids = batch['input_ids'].to(self.device)
        attention_mask = batch['attention_mask'].to(self.device)
        
        # Zero gradients
        self.optimizer.zero_grad()
        
        # FORWARD PASS - Model computes predictions
        logits = self.model(input_ids, attention_mask)  # (batch, seq_len, vocab_size)
        
        # LOSS CALCULATION - Cross-entropy for language modeling
        # Shift logits and labels for next-token prediction
        shift_logits = logits[:, :-1, :].contiguous()  # (batch, seq_len-1, vocab_size)
        shift_labels = input_ids[:, 1:].contiguous()   # (batch, seq_len-1)
        shift_mask = attention_mask[:, 1:].contiguous() # (batch, seq_len-1)
        
        # Compute loss (ignore padding tokens)
        loss = F.cross_entropy(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
            reduction='none'
        )
        
        # Apply mask and average
        loss = (loss * shift_mask.view(-1)).sum() / shift_mask.sum()
        
        # Check for NaN/Inf
        if torch.isnan(loss) or torch.isinf(loss):
            print(f"✗ NaN/Inf loss detected: {loss.item()}")
            return {'loss': float('inf'), 'ppl': float('inf'), 'grad_norm': 0.0}
        
        # BACKWARD PASS - Compute gradients
        loss.backward()
        
        # Check for NaN/Inf in gradients
        has_nan_grad = False
        for param in self.model.parameters():
            if param.grad is not None:
                if torch.isnan(param.grad).any() or torch.isinf(param.grad).any():
                    has_nan_grad = True
                    break
        
        if has_nan_grad:
            print(f"✗ NaN/Inf in gradients")
            self.optimizer.zero_grad()
            return {'loss': loss.item(), 'ppl': float('inf'), 'grad_norm': 0.0}
        
        # Gradient clipping
        grad_norm = torch.nn.utils.clip_grad_norm_(
            self.model.parameters(),
            self.max_grad_norm
        ).item()
        
        # OPTIMIZER STEP - Update weights
        self.optimizer.step()
        
        # Update learning rate
        current_lr = self._update_lr()
        
        self.global_step += 1
        
        # Compute perplexity
        ppl = math.exp(min(loss.item(), 20))  # Cap for numerical stability
        
        # Record metrics
        self.metrics['train_losses'].append(loss.item())
        self.metrics['train_ppls'].append(ppl)
        self.metrics['grad_norms'].append(grad_norm)
        self.metrics['learning_rates'].append(current_lr)
        
        return {
            'loss': loss.item(),
            'ppl': ppl,
            'grad_norm': grad_norm,
            'lr': current_lr
        }
    
    def train_epoch(self, epoch: int) -> Dict[str, float]:
        """
        Train for one epoch.
        
        Returns:
            epoch_metrics: average metrics for the epoch
        """
        print(f"\n{'='*70}")
        print(f"EPOCH {epoch}")
        print(f"{'='*70}")
        
        epoch_losses = []
        epoch_ppls = []
        epoch_grad_norms = []
        
        start_time = time.time()
        
        for batch_idx, batch in enumerate(self.train_loader):
            step_start = time.time()
            
            # Single training step
            metrics = self.train_step(batch)
            
            step_time = time.time() - step_start
            self.metrics['step_times'].append(step_time)
            
            epoch_losses.append(metrics['loss'])
            epoch_ppls.append(metrics['ppl'])
            epoch_grad_norms.append(metrics['grad_norm'])
            
            # Log every N steps
            if batch_idx % 50 == 0:
                print(f"  Step {batch_idx}/{len(self.train_loader)}: "
                      f"Loss={metrics['loss']:.4f}, "
                      f"PPL={metrics['ppl']:.2f}, "
                      f"GradNorm={metrics['grad_norm']:.4f}, "
                      f"LR={metrics['lr']:.2e}, "
                      f"Time={step_time:.3f}s")
        
        epoch_time = time.time() - start_time
        
        # Epoch summary
        avg_loss = sum(epoch_losses) / len(epoch_losses)
        avg_ppl = sum(epoch_ppls) / len(epoch_ppls)
        avg_grad_norm = sum(epoch_grad_norms) / len(epoch_grad_norms)
        
        print(f"\n{'='*70}")
        print(f"EPOCH {epoch} SUMMARY")
        print(f"{'='*70}")
        print(f"Avg Loss: {avg_loss:.4f}")
        print(f"Avg PPL: {avg_ppl:.2f}")
        print(f"Avg Grad Norm: {avg_grad_norm:.4f}")
        print(f"Epoch Time: {epoch_time:.1f}s")
        print(f"{'='*70}")
        
        return {
            'avg_loss': avg_loss,
            'avg_ppl': avg_ppl,
            'avg_grad_norm': avg_grad_norm,
            'epoch_time': epoch_time
        }
    
    @torch.no_grad()
    def validate(self) -> Tuple[float, float]:
        """
        Validate on validation set.
        
        Returns:
            (avg_loss, avg_ppl)
        """
        self.model.eval()
        
        total_loss = 0.0
        total_tokens = 0
        
        for batch in self.val_loader:
            input_ids = batch['input_ids'].to(self.device)
            attention_mask = batch['attention_mask'].to(self.device)
            
            # Forward pass
            logits = self.model(input_ids, attention_mask)
            
            # Compute loss
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = input_ids[:, 1:].contiguous()
            shift_mask = attention_mask[:, 1:].contiguous()
            
            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                reduction='none'
            )
            
            # Apply mask
            masked_loss = (loss * shift_mask.view(-1)).sum()
            num_tokens = shift_mask.sum()
            
            total_loss += masked_loss.item()
            total_tokens += num_tokens.item()
        
        avg_loss = total_loss / max(total_tokens, 1)
        avg_ppl = math.exp(min(avg_loss, 20))
        
        # Record validation metrics
        self.metrics['val_losses'].append(avg_loss)
        self.metrics['val_ppls'].append(avg_ppl)
        
        print(f"\nVALIDATION: Loss={avg_loss:.4f}, PPL={avg_ppl:.2f}")
        
        return avg_loss, avg_ppl
    
    def train(self, num_epochs: int) -> Dict:
        """
        Complete training loop.
        
        Args:
            num_epochs: number of epochs to train
            
        Returns:
            training_history: complete metrics
        """
        print(f"\n{'='*70}")
        print(f"BEGINNING TRAINING: {num_epochs} EPOCHS")
        print(f"{'='*70}")
        
        history = {
            'epochs': [],
            'train_losses': [],
            'train_ppls': [],
            'val_losses': [],
            'val_ppls': []
        }
        
        # Initial validation
        print("\nInitial validation...")
        val_loss, val_ppl = self.validate()
        history['val_losses'].append(val_loss)
        history['val_ppls'].append(val_ppl)
        
        # Training loop
        for epoch in range(1, num_epochs + 1):
            # Train epoch
            epoch_metrics = self.train_epoch(epoch)
            
            # Validate
            val_loss, val_ppl = self.validate()
            
            # Record history
            history['epochs'].append(epoch)
            history['train_losses'].append(epoch_metrics['avg_loss'])
            history['train_ppls'].append(epoch_metrics['avg_ppl'])
            history['val_losses'].append(val_loss)
            history['val_ppls'].append(val_ppl)
        
        print(f"\n{'='*70}")
        print("TRAINING COMPLETE")
        print(f"{'='*70}")
        print(f"Initial validation PPL: {history['val_ppls'][0]:.2f}")
        print(f"Final validation PPL: {history['val_ppls'][-1]:.2f}")
        
        improvement = ((history['val_ppls'][0] - history['val_ppls'][-1]) / history['val_ppls'][0]) * 100
        print(f"Improvement: {improvement:.1f}%")
        print(f"{'='*70}")
        
        return history
    
    def save_checkpoint(self, path: str):
        """Save model checkpoint."""
        checkpoint = {
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'global_step': self.global_step,
            'metrics': self.metrics,
            'config': self.model.config.__dict__
        }
        
        torch.save(checkpoint, path)
        print(f"✓ Checkpoint saved: {path}")
    
    def load_checkpoint(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.global_step = checkpoint['global_step']
        self.metrics = checkpoint.get('metrics', self.metrics)
        
        print(f"✓ Checkpoint loaded: {path}")
        print(f"  Global step: {self.global_step}")


# ============================================================================
# SIMPLE DATASET
# ============================================================================

class TextDataset(Dataset):
    """Simple text dataset."""
    
    def __init__(self, encodings: Dict[str, torch.Tensor]):
        self.input_ids = encodings['input_ids']
        self.attention_mask = encodings['attention_mask']
    
    def __len__(self):
        return len(self.input_ids)
    
    def __getitem__(self, idx):
        return {
            'input_ids': self.input_ids[idx],
            'attention_mask': self.attention_mask[idx]
        }


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    print("Testing Training Engine...")
    print("="*70)
    
    # Create model
    config = ModelConfig(
        vocab_size=1000,
        max_seq_len=128,
        d_model=256,
        num_layers=4,
        num_heads=4,
        d_ff=1024
    )
    
    model = AIKLILanguageModel(config)
    
    # Create dummy data
    batch_size = 4
    seq_len = 64
    num_batches = 10
    
    dummy_data = {
        'input_ids': torch.randint(0, 1000, (num_batches * batch_size, seq_len)),
        'attention_mask': torch.ones(num_batches * batch_size, seq_len)
    }
    
    dataset = TextDataset(dummy_data)
    train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    
    # Create trainer
    engine = TrainingEngine(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        learning_rate=3e-4,
        device='cpu'  # Use CPU for testing
    )
    
    # Test single step
    print("\nTesting single training step...")
    batch = next(iter(train_loader))
    metrics = engine.train_step(batch)
    print(f"✓ Single step: Loss={metrics['loss']:.4f}, PPL={metrics['ppl']:.2f}")
    
    # Test validation
    print("\nTesting validation...")
    val_loss, val_ppl = engine.validate()
    print(f"✓ Validation: Loss={val_loss:.4f}, PPL={val_ppl:.2f}")
    
    # Test generation
    print("\nTesting generation...")
    input_ids = torch.randint(0, 1000, (1, 10))
    generated = model.generate(input_ids, max_new_tokens=20, temperature=0.8)
    print(f"✓ Generated {generated.shape[1]} tokens")
    
    # Test checkpoint save/load
    print("\nTesting checkpoint...")
    engine.save_checkpoint('./test_checkpoint.pt')
    engine.load_checkpoint('./test_checkpoint.pt')
    print("✓ Checkpoint save/load works")
    
    print("\n" + "="*70)
    print("✓ ALL TESTS PASSED - TRAINING ENGINE READY")
    print("="*70)
